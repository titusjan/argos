argos.repo.detailplugins.quicklook module
=========================================

.. automodule:: argos.repo.detailplugins.quicklook
   :members:
   :undoc-members:
   :show-inheritance:
