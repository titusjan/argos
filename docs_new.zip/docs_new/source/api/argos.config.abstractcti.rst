argos.config.abstractcti module
===============================

.. automodule:: argos.config.abstractcti
   :members:
   :undoc-members:
   :show-inheritance:
