argos.repo.detailpanes module
=============================

.. automodule:: argos.repo.detailpanes
   :members:
   :undoc-members:
   :show-inheritance:
