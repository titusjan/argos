argos.widgets package
=====================

.. automodule:: argos.widgets
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   argos.widgets.aboutdialog
   argos.widgets.argostableview
   argos.widgets.argostreeview
   argos.widgets.constants
   argos.widgets.display
   argos.widgets.mainwindow
   argos.widgets.misc
   argos.widgets.testwalkdialog
