argos.utils.defs module
=======================

.. automodule:: argos.utils.defs
   :members:
   :undoc-members:
   :show-inheritance:
