argos.repo.detailplugins package
================================

.. automodule:: argos.repo.detailplugins
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   argos.repo.detailplugins.attr
   argos.repo.detailplugins.prop
   argos.repo.detailplugins.quicklook
