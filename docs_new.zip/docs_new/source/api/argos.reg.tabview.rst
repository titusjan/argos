argos.reg.tabview module
========================

.. automodule:: argos.reg.tabview
   :members:
   :undoc-members:
   :show-inheritance:
