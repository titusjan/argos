argos.inspector package
=======================

.. automodule:: argos.inspector
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   argos.inspector.pgplugins
   argos.inspector.qtplugins

Submodules
----------

.. toctree::
   :maxdepth: 4

   argos.inspector.abstract
   argos.inspector.debug
   argos.inspector.dialog
   argos.inspector.errormsg
   argos.inspector.registry
   argos.inspector.selectionpane
