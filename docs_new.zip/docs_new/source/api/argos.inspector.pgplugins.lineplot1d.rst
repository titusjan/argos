argos.inspector.pgplugins.lineplot1d module
===========================================

.. automodule:: argos.inspector.pgplugins.lineplot1d
   :members:
   :undoc-members:
   :show-inheritance:
