argos.repo.registry module
==========================

.. automodule:: argos.repo.registry
   :members:
   :undoc-members:
   :show-inheritance:
