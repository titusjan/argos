argos.collect package
=====================

.. automodule:: argos.collect
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   argos.collect.collector
   argos.collect.collectortree
