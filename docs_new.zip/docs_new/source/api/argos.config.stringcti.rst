argos.config.stringcti module
=============================

.. automodule:: argos.config.stringcti
   :members:
   :undoc-members:
   :show-inheritance:
