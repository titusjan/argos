argos.inspector.pgplugins.colorbar module
=========================================

.. automodule:: argos.inspector.pgplugins.colorbar
   :members:
   :undoc-members:
   :show-inheritance:
