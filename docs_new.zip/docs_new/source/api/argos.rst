argos package
=============

.. automodule:: argos
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   argos.collect
   argos.config
   argos.inspector
   argos.qt
   argos.reg
   argos.repo
   argos.utils
   argos.widgets

Submodules
----------

.. toctree::
   :maxdepth: 4

   argos.application
   argos.argos_make_wrappers
   argos.info
   argos.main
   argos.mytest
