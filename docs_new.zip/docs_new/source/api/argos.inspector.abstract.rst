argos.inspector.abstract module
===============================

.. automodule:: argos.inspector.abstract
   :members:
   :undoc-members:
   :show-inheritance:
