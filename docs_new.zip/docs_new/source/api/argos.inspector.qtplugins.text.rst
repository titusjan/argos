argos.inspector.qtplugins.text module
=====================================

.. automodule:: argos.inspector.qtplugins.text
   :members:
   :undoc-members:
   :show-inheritance:
