argos.utils.dirs module
=======================

.. automodule:: argos.utils.dirs
   :members:
   :undoc-members:
   :show-inheritance:
