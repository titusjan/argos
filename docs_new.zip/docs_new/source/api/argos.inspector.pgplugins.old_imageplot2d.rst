argos.inspector.pgplugins.old\_imageplot2d module
=================================================

.. automodule:: argos.inspector.pgplugins.old_imageplot2d
   :members:
   :undoc-members:
   :show-inheritance:
