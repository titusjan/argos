argos.qt.shortcutedit module
============================

.. automodule:: argos.qt.shortcutedit
   :members:
   :undoc-members:
   :show-inheritance:
