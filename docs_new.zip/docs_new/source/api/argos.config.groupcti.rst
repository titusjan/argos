argos.config.groupcti module
============================

.. automodule:: argos.config.groupcti
   :members:
   :undoc-members:
   :show-inheritance:
