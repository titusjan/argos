argos.inspector.selectionpane module
====================================

.. automodule:: argos.inspector.selectionpane
   :members:
   :undoc-members:
   :show-inheritance:
