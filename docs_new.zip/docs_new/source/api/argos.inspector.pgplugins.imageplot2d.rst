argos.inspector.pgplugins.imageplot2d module
============================================

.. automodule:: argos.inspector.pgplugins.imageplot2d
   :members:
   :undoc-members:
   :show-inheritance:
