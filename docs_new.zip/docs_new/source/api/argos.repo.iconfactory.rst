argos.repo.iconfactory module
=============================

.. automodule:: argos.repo.iconfactory
   :members:
   :undoc-members:
   :show-inheritance:
