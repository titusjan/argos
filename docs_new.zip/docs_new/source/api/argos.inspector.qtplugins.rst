argos.inspector.qtplugins package
=================================

.. automodule:: argos.inspector.qtplugins
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   argos.inspector.qtplugins.table
   argos.inspector.qtplugins.text
