argos.widgets.aboutdialog module
================================

.. automodule:: argos.widgets.aboutdialog
   :members:
   :undoc-members:
   :show-inheritance:
