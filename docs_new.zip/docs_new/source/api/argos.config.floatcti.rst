argos.config.floatcti module
============================

.. automodule:: argos.config.floatcti
   :members:
   :undoc-members:
   :show-inheritance:
