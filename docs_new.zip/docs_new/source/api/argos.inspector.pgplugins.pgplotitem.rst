argos.inspector.pgplugins.pgplotitem module
===========================================

.. automodule:: argos.inspector.pgplugins.pgplotitem
   :members:
   :undoc-members:
   :show-inheritance:
