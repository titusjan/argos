argos.config.configitemdelegate module
======================================

.. automodule:: argos.config.configitemdelegate
   :members:
   :undoc-members:
   :show-inheritance:
