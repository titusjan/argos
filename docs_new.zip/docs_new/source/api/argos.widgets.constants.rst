argos.widgets.constants module
==============================

.. automodule:: argos.widgets.constants
   :members:
   :undoc-members:
   :show-inheritance:
