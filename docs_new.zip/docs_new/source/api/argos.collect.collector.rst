argos.collect.collector module
==============================

.. automodule:: argos.collect.collector
   :members:
   :undoc-members:
   :show-inheritance:
