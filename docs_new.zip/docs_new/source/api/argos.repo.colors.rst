argos.repo.colors module
========================

.. automodule:: argos.repo.colors
   :members:
   :undoc-members:
   :show-inheritance:
