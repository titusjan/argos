argos.reg.basereg module
========================

.. automodule:: argos.reg.basereg
   :members:
   :undoc-members:
   :show-inheritance:
