argos.inspector.dialog module
=============================

.. automodule:: argos.inspector.dialog
   :members:
   :undoc-members:
   :show-inheritance:
