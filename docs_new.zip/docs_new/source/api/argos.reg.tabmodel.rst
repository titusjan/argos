argos.reg.tabmodel module
=========================

.. automodule:: argos.reg.tabmodel
   :members:
   :undoc-members:
   :show-inheritance:
