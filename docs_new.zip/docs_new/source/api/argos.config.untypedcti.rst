argos.config.untypedcti module
==============================

.. automodule:: argos.config.untypedcti
   :members:
   :undoc-members:
   :show-inheritance:
