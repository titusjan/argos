argos.config.configtreemodel module
===================================

.. automodule:: argos.config.configtreemodel
   :members:
   :undoc-members:
   :show-inheritance:
