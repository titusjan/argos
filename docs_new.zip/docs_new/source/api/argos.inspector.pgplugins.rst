argos.inspector.pgplugins package
=================================

.. automodule:: argos.inspector.pgplugins
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   argos.inspector.pgplugins.colorbar
   argos.inspector.pgplugins.imageplot2d
   argos.inspector.pgplugins.lineplot1d
   argos.inspector.pgplugins.old_imageplot2d
   argos.inspector.pgplugins.pgctis
   argos.inspector.pgplugins.pghistlutitem
   argos.inspector.pgplugins.pgplotitem
