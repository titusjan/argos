argos.reg package
=================

.. automodule:: argos.reg
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   argos.reg.basereg
   argos.reg.dialog
   argos.reg.tabmodel
   argos.reg.tabview
