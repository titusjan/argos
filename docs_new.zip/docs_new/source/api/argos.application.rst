argos.application module
========================

.. automodule:: argos.application
   :members:
   :undoc-members:
   :show-inheritance:
