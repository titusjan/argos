argos.widgets.argostableview module
===================================

.. automodule:: argos.widgets.argostableview
   :members:
   :undoc-members:
   :show-inheritance:
