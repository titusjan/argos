argos.repo.detailplugins.prop module
====================================

.. automodule:: argos.repo.detailplugins.prop
   :members:
   :undoc-members:
   :show-inheritance:
