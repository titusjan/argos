argos.reg.dialog module
=======================

.. automodule:: argos.reg.dialog
   :members:
   :undoc-members:
   :show-inheritance:
