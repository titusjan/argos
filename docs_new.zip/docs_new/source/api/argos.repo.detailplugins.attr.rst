argos.repo.detailplugins.attr module
====================================

.. automodule:: argos.repo.detailplugins.attr
   :members:
   :undoc-members:
   :show-inheritance:
