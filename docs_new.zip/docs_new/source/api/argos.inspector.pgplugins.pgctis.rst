argos.inspector.pgplugins.pgctis module
=======================================

.. automodule:: argos.inspector.pgplugins.pgctis
   :members:
   :undoc-members:
   :show-inheritance:
