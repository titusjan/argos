argos.inspector.pgplugins.pghistlutitem module
==============================================

.. automodule:: argos.inspector.pgplugins.pghistlutitem
   :members:
   :undoc-members:
   :show-inheritance:
