argos.qt.colorselect module
===========================

.. automodule:: argos.qt.colorselect
   :members:
   :undoc-members:
   :show-inheritance:
