argos.config.choicecti module
=============================

.. automodule:: argos.config.choicecti
   :members:
   :undoc-members:
   :show-inheritance:
