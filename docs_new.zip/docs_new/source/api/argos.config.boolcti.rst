argos.config.boolcti module
===========================

.. automodule:: argos.config.boolcti
   :members:
   :undoc-members:
   :show-inheritance:
