argos.collect.collectortree module
==================================

.. automodule:: argos.collect.collectortree
   :members:
   :undoc-members:
   :show-inheritance:
