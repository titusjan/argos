argos.widgets.mainwindow module
===============================

.. automodule:: argos.widgets.mainwindow
   :members:
   :undoc-members:
   :show-inheritance:
